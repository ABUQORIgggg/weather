module.exports  = {
    theme: {
      extend: {
        backgroundColor: {
          'night-800': '#1A202C',  // Dark gray
          'night-600': '#2C3E50',  // Midnight blue
        },
      },
    },
    variants: {},
    plugins: [],
  }
  